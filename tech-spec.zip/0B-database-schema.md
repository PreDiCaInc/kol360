# Module 0B: Database Schema (Prisma)

## Objective
Define complete Prisma schema for all KOL360 entities with proper relationships, indexes, and enums.

## Prerequisites
- Module 0A completed
- PostgreSQL running via Docker

---

## Prisma Setup

```bash
cd apps/api
pnpm add prisma @prisma/client
pnpm prisma init
```

---

## Complete Schema

`apps/api/prisma/schema.prisma`:

```prisma
generator client {
  provider = "prisma-client-js"
}

datasource db {
  provider = "postgresql"
  url      = env("DATABASE_URL")
}

// ============================================
// ENUMS
// ============================================

enum UserRole {
  PLATFORM_ADMIN
  CLIENT_ADMIN
  TEAM_MEMBER
}

enum UserStatus {
  PENDING_VERIFICATION
  PENDING_APPROVAL
  ACTIVE
  DISABLED
}

enum ClientType {
  FULL
  LITE
}

enum CampaignStatus {
  DRAFT
  ACTIVE
  CLOSED
  PUBLISHED
}

enum SurveyResponseStatus {
  PENDING
  OPENED
  IN_PROGRESS
  COMPLETED
}

enum NominationMatchStatus {
  UNMATCHED
  MATCHED
  NEW_HCP
  EXCLUDED
}

enum PaymentStatus {
  PENDING_EXPORT
  EXPORTED
  EMAIL_SENT
  EMAIL_DELIVERED
  EMAIL_OPENED
  CLAIMED
  BOUNCED
  REJECTED
  EXPIRED
}

enum OptOutScope {
  CAMPAIGN
  GLOBAL
}

enum QuestionType {
  TEXT
  NUMBER
  RATING
  SINGLE_CHOICE
  MULTI_CHOICE
  DROPDOWN
  MULTI_TEXT
}

// ============================================
// TENANT & USER MANAGEMENT
// ============================================

model Client {
  id           String     @id @default(cuid())
  name         String
  type         ClientType @default(FULL)
  logoUrl      String?
  primaryColor String     @default("#0066CC")
  isActive     Boolean    @default(true)

  createdAt DateTime @default(now())
  updatedAt DateTime @updatedAt

  // Relations
  users                  User[]
  campaigns              Campaign[]
  liteClientDiseaseAreas LiteClientDiseaseArea[]

  @@index([type])
  @@index([isActive])
}

model User {
  id          String     @id @default(cuid())
  cognitoSub  String     @unique
  email       String     @unique
  firstName   String
  lastName    String
  role        UserRole
  status      UserStatus @default(PENDING_VERIFICATION)

  clientId String?
  client   Client? @relation(fields: [clientId], references: [id])

  approvedAt  DateTime?
  approvedBy  String?
  lastLoginAt DateTime?

  createdAt DateTime @default(now())
  updatedAt DateTime @updatedAt

  // Relations
  auditLogs AuditLog[]

  @@index([clientId])
  @@index([email])
  @@index([cognitoSub])
  @@index([status])
}

// ============================================
// DISEASE AREAS
// ============================================

model DiseaseArea {
  id              String  @id @default(cuid())
  therapeuticArea String // e.g., "Ophthalmology"
  name            String // e.g., "Retina", "Dry Eye"
  code            String  @unique // e.g., "RETINA", "DRY_EYE"
  isActive        Boolean @default(true)

  createdAt DateTime @default(now())
  updatedAt DateTime @updatedAt

  // Relations
  campaigns              Campaign[]
  hcpDiseaseAreaScores   HcpDiseaseAreaScore[]
  liteClientDiseaseAreas LiteClientDiseaseArea[]

  @@index([therapeuticArea])
  @@index([isActive])
}

model LiteClientDiseaseArea {
  id            String      @id @default(cuid())
  clientId      String
  client        Client      @relation(fields: [clientId], references: [id])
  diseaseAreaId String
  diseaseArea   DiseaseArea @relation(fields: [diseaseAreaId], references: [id])

  isActive  Boolean   @default(true)
  expiresAt DateTime?
  grantedBy String
  grantedAt DateTime  @default(now())

  @@unique([clientId, diseaseAreaId])
  @@index([clientId])
  @@index([diseaseAreaId])
}

// ============================================
// HCP (Healthcare Provider)
// ============================================

model Hcp {
  id              String  @id @default(cuid())
  npi             String  @unique
  firstName       String
  lastName        String
  email           String?
  specialty       String?
  subSpecialty    String?
  city            String?
  state           String?
  yearsInPractice Int?

  createdAt DateTime @default(now())
  updatedAt DateTime @updatedAt
  createdBy String?

  // Relations
  aliases             HcpAlias[]
  diseaseAreaScores   HcpDiseaseAreaScore[]
  campaignScores      HcpCampaignScore[]
  campaignHcps        CampaignHcp[]
  nominationsReceived Nomination[]       @relation("NominatedHcp")
  nominationsGiven    Nomination[]       @relation("NominatorHcp")
  surveyResponses     SurveyResponse[]
  payments            Payment[]

  @@index([npi])
  @@index([lastName, firstName])
  @@index([specialty])
  @@index([state])
}

model HcpAlias {
  id        String   @id @default(cuid())
  hcpId     String
  hcp       Hcp      @relation(fields: [hcpId], references: [id], onDelete: Cascade)
  aliasName String
  createdBy String?
  createdAt DateTime @default(now())

  @@unique([hcpId, aliasName])
  @@index([aliasName])
}

// ============================================
// SCORING
// ============================================

model HcpDiseaseAreaScore {
  id            String      @id @default(cuid())
  hcpId         String
  hcp           Hcp         @relation(fields: [hcpId], references: [id], onDelete: Cascade)
  diseaseAreaId String
  diseaseArea   DiseaseArea @relation(fields: [diseaseAreaId], references: [id])

  // 8 Objective Scores (0-100, manually uploaded)
  scorePublications   Decimal? @db.Decimal(5, 2)
  scoreClinicalTrials Decimal? @db.Decimal(5, 2)
  scoreTradePubs      Decimal? @db.Decimal(5, 2)
  scoreOrgLeadership  Decimal? @db.Decimal(5, 2)
  scoreOrgAwareness   Decimal? @db.Decimal(5, 2)
  scoreConference     Decimal? @db.Decimal(5, 2)
  scoreSocialMedia    Decimal? @db.Decimal(5, 2)
  scoreMediaPodcasts  Decimal? @db.Decimal(5, 2)

  // Survey Score (0-100, system-calculated aggregate)
  scoreSurvey          Decimal? @db.Decimal(5, 2)
  totalNominationCount Int      @default(0)

  // Composite Score
  compositeScore Decimal? @db.Decimal(5, 2)

  // SCD Type 2 fields for history tracking
  isCurrent     Boolean   @default(true)
  effectiveFrom DateTime  @default(now())
  effectiveTo   DateTime?

  // Metadata
  campaignCount    Int       @default(0)
  lastCalculatedAt DateTime?

  createdAt DateTime @default(now())
  updatedAt DateTime @updatedAt

  @@index([hcpId, diseaseAreaId, isCurrent])
  @@index([diseaseAreaId, isCurrent])
  @@index([hcpId, isCurrent])
}

model HcpCampaignScore {
  id         String   @id @default(cuid())
  hcpId      String
  hcp        Hcp      @relation(fields: [hcpId], references: [id], onDelete: Cascade)
  campaignId String
  campaign   Campaign @relation(fields: [campaignId], references: [id], onDelete: Cascade)

  // Campaign Survey Score (this campaign only)
  scoreSurvey     Decimal? @db.Decimal(5, 2)
  nominationCount Int      @default(0)

  // Campaign Composite (8 from disease area + 1 survey from campaign)
  compositeScore Decimal? @db.Decimal(5, 2)

  calculatedAt DateTime?
  publishedAt  DateTime?

  createdAt DateTime @default(now())
  updatedAt DateTime @updatedAt

  @@unique([hcpId, campaignId])
  @@index([campaignId])
  @@index([hcpId])
}

model ScoreImportBatch {
  id            String  @id @default(cuid())
  diseaseAreaId String
  fileName      String
  recordsTotal  Int
  recordsImported Int
  recordsSkipped  Int
  importedBy    String
  importedAt    DateTime @default(now())
  notes         String?

  @@index([diseaseAreaId])
  @@index([importedAt])
}

// ============================================
// QUESTION BANK
// ============================================

model Question {
  id         String       @id @default(cuid())
  text       String
  type       QuestionType
  category   String? // e.g., "Demographics", "Nominations"
  isRequired Boolean      @default(false)
  options    Json? // For choice questions: ["Option A", "Option B"]
  tags       String[]
  status     String       @default("active") // active, archived
  usageCount Int          @default(0)

  createdAt DateTime @default(now())
  updatedAt DateTime @updatedAt

  // Relations
  sectionQuestions SectionQuestion[]
  surveyQuestions  SurveyQuestion[]

  @@index([category])
  @@index([type])
  @@index([status])
}

model SectionTemplate {
  id          String  @id @default(cuid())
  name        String
  description String?
  isCore      Boolean @default(false)
  sortOrder   Int     @default(0)

  createdAt DateTime @default(now())
  updatedAt DateTime @updatedAt

  // Relations
  questions        SectionQuestion[]
  templateSections TemplateSection[]

  @@index([isCore])
}

model SectionQuestion {
  id         String          @id @default(cuid())
  sectionId  String
  section    SectionTemplate @relation(fields: [sectionId], references: [id], onDelete: Cascade)
  questionId String
  question   Question        @relation(fields: [questionId], references: [id])
  sortOrder  Int             @default(0)

  @@unique([sectionId, questionId])
  @@index([sectionId])
}

model SurveyTemplate {
  id          String  @id @default(cuid())
  name        String
  description String?

  createdAt DateTime @default(now())
  updatedAt DateTime @updatedAt

  // Relations
  sections  TemplateSection[]
  campaigns Campaign[]
}

model TemplateSection {
  id         String          @id @default(cuid())
  templateId String
  template   SurveyTemplate  @relation(fields: [templateId], references: [id], onDelete: Cascade)
  sectionId  String
  section    SectionTemplate @relation(fields: [sectionId], references: [id])
  sortOrder  Int             @default(0)
  isLocked   Boolean         @default(false)

  @@unique([templateId, sectionId])
  @@index([templateId])
}

// ============================================
// CAMPAIGNS
// ============================================

model Campaign {
  id               String          @id @default(cuid())
  clientId         String
  client           Client          @relation(fields: [clientId], references: [id])
  diseaseAreaId    String
  diseaseArea      DiseaseArea     @relation(fields: [diseaseAreaId], references: [id])
  surveyTemplateId String?
  surveyTemplate   SurveyTemplate? @relation(fields: [surveyTemplateId], references: [id])

  name        String
  description String?
  status      CampaignStatus @default(DRAFT)

  honorariumAmount Decimal? @db.Decimal(10, 2)

  surveyOpenDate  DateTime?
  surveyCloseDate DateTime?
  publishedAt     DateTime?

  createdAt DateTime @default(now())
  updatedAt DateTime @updatedAt
  createdBy String?

  // Relations
  campaignHcps         CampaignHcp[]
  surveyQuestions      SurveyQuestion[]
  surveyResponses      SurveyResponse[]
  hcpCampaignScores    HcpCampaignScore[]
  compositeScoreConfig CompositeScoreConfig?
  payments             Payment[]
  optOuts              OptOut[]

  @@index([clientId])
  @@index([diseaseAreaId])
  @@index([status])
}

model CampaignHcp {
  id         String   @id @default(cuid())
  campaignId String
  campaign   Campaign @relation(fields: [campaignId], references: [id], onDelete: Cascade)
  hcpId      String
  hcp        Hcp      @relation(fields: [hcpId], references: [id])

  surveyToken    String    @unique @default(cuid())
  emailSentAt    DateTime?
  reminderCount  Int       @default(0)
  lastReminderAt DateTime?

  createdAt DateTime @default(now())

  @@unique([campaignId, hcpId])
  @@index([surveyToken])
  @@index([campaignId])
}

model SurveyQuestion {
  id         String   @id @default(cuid())
  campaignId String
  campaign   Campaign @relation(fields: [campaignId], references: [id], onDelete: Cascade)
  questionId String
  question   Question @relation(fields: [questionId], references: [id])

  sectionName          String
  sortOrder            Int     @default(0)
  isRequired           Boolean @default(false)
  questionTextSnapshot String // Frozen copy of question text

  createdAt DateTime @default(now())

  // Relations
  answers     SurveyResponseAnswer[]
  nominations Nomination[]

  @@index([campaignId])
}

model CompositeScoreConfig {
  id         String   @id @default(cuid())
  campaignId String   @unique
  campaign   Campaign @relation(fields: [campaignId], references: [id], onDelete: Cascade)

  // Weights for each segment (must sum to 100)
  weightPublications   Decimal @default(10) @db.Decimal(5, 2)
  weightClinicalTrials Decimal @default(15) @db.Decimal(5, 2)
  weightTradePubs      Decimal @default(10) @db.Decimal(5, 2)
  weightOrgLeadership  Decimal @default(10) @db.Decimal(5, 2)
  weightOrgAwareness   Decimal @default(10) @db.Decimal(5, 2)
  weightConference     Decimal @default(10) @db.Decimal(5, 2)
  weightSocialMedia    Decimal @default(5) @db.Decimal(5, 2)
  weightMediaPodcasts  Decimal @default(5) @db.Decimal(5, 2)
  weightSurvey         Decimal @default(25) @db.Decimal(5, 2)

  createdAt DateTime @default(now())
  updatedAt DateTime @updatedAt
}

// ============================================
// SURVEY RESPONSES
// ============================================

model SurveyResponse {
  id              String               @id @default(cuid())
  campaignId      String
  campaign        Campaign             @relation(fields: [campaignId], references: [id])
  respondentHcpId String
  respondentHcp   Hcp                  @relation(fields: [respondentHcpId], references: [id])
  surveyToken     String               @unique

  status      SurveyResponseStatus @default(PENDING)
  startedAt   DateTime?
  completedAt DateTime?
  ipAddress   String?

  createdAt DateTime @default(now())
  updatedAt DateTime @updatedAt

  // Relations
  answers     SurveyResponseAnswer[]
  nominations Nomination[]
  payment     Payment?

  @@index([campaignId])
  @@index([respondentHcpId])
  @@index([surveyToken])
  @@index([status])
}

model SurveyResponseAnswer {
  id         String         @id @default(cuid())
  responseId String
  response   SurveyResponse @relation(fields: [responseId], references: [id], onDelete: Cascade)
  questionId String
  question   SurveyQuestion @relation(fields: [questionId], references: [id])

  answerText String?
  answerJson Json?

  createdAt DateTime @default(now())
  updatedAt DateTime @updatedAt

  @@index([responseId])
  @@index([questionId])
}

model Nomination {
  id             String         @id @default(cuid())
  responseId     String
  response       SurveyResponse @relation(fields: [responseId], references: [id], onDelete: Cascade)
  questionId     String
  question       SurveyQuestion @relation(fields: [questionId], references: [id])
  nominatorHcpId String
  nominatorHcp   Hcp            @relation("NominatorHcp", fields: [nominatorHcpId], references: [id])

  rawNameEntered String
  matchedHcpId   String?
  matchedHcp     Hcp?                  @relation("NominatedHcp", fields: [matchedHcpId], references: [id])
  matchStatus    NominationMatchStatus @default(UNMATCHED)
  matchedBy      String?
  matchedAt      DateTime?

  createdAt DateTime @default(now())

  @@index([responseId])
  @@index([questionId])
  @@index([matchStatus])
  @@index([matchedHcpId])
  @@index([rawNameEntered])
}

// ============================================
// PAYMENTS
// ============================================

model Payment {
  id         String         @id @default(cuid())
  campaignId String
  campaign   Campaign       @relation(fields: [campaignId], references: [id])
  hcpId      String
  hcp        Hcp            @relation(fields: [hcpId], references: [id])
  responseId String         @unique
  response   SurveyResponse @relation(fields: [responseId], references: [id])

  amount   Decimal       @db.Decimal(10, 2)
  currency String        @default("USD")

  status          PaymentStatus @default(PENDING_EXPORT)
  statusUpdatedAt DateTime?

  exportedAt    DateTime?
  exportBatchId String?
  exportBatch   PaymentExportBatch? @relation(fields: [exportBatchId], references: [id])

  externalReferenceId String?

  createdAt DateTime @default(now())
  updatedAt DateTime @updatedAt

  // Relations
  statusHistory PaymentStatusHistory[]

  @@unique([campaignId, hcpId])
  @@index([campaignId])
  @@index([status])
}

model PaymentExportBatch {
  id          String   @id @default(cuid())
  campaignId  String
  exportedBy  String
  exportedAt  DateTime @default(now())
  recordCount Int
  fileName    String?
  notes       String?

  // Relations
  payments Payment[]

  @@index([campaignId])
}

model PaymentStatusHistory {
  id            String        @id @default(cuid())
  paymentId     String
  payment       Payment       @relation(fields: [paymentId], references: [id], onDelete: Cascade)
  oldStatus     PaymentStatus?
  newStatus     PaymentStatus
  changedAt     DateTime      @default(now())
  changedBy     String?
  importBatchId String?

  @@index([paymentId])
}

model PaymentImportBatch {
  id             String   @id @default(cuid())
  campaignId     String
  importedBy     String
  importedAt     DateTime @default(now())
  fileName       String
  recordCount    Int
  matchedCount   Int
  unmatchedCount Int
  status         String // processing, completed, completed_with_errors

  @@index([campaignId])
}

// ============================================
// OPT-OUT
// ============================================

model OptOut {
  id         String       @id @default(cuid())
  hcpId      String?
  email      String
  scope      OptOutScope
  campaignId String?
  campaign   Campaign?    @relation(fields: [campaignId], references: [id])

  reason      String?
  optedOutAt  DateTime @default(now())
  optedOutVia String // email_link, admin_manual, api

  resubscribedAt  DateTime?
  resubscribedVia String?

  createdAt DateTime @default(now())
  updatedAt DateTime @updatedAt

  @@index([email])
  @@index([scope])
  @@index([campaignId])
}

// ============================================
// AUDIT LOG
// ============================================

model AuditLog {
  id         String   @id @default(cuid())
  userId     String?
  user       User?    @relation(fields: [userId], references: [id])
  action     String // e.g., "hcp.created", "campaign.published"
  entityType String // e.g., "Hcp", "Campaign"
  entityId   String
  oldValues  Json?
  newValues  Json?
  ipAddress  String?
  userAgent  String?

  createdAt DateTime @default(now())

  @@index([entityType, entityId])
  @@index([userId])
  @@index([action])
  @@index([createdAt])
}

// ============================================
// DASHBOARD CONFIG (Phase 2)
// ============================================

model DashboardConfig {
  id         String  @id @default(cuid())
  clientId   String?
  campaignId String?
  name       String
  config     Json // Stores visualization config

  createdAt DateTime @default(now())
  updatedAt DateTime @updatedAt

  @@index([clientId])
  @@index([campaignId])
}
```

---

## Seed Data

`apps/api/prisma/seed.ts`:

```typescript
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

async function main() {
  console.log('🌱 Seeding database...');

  // Create Disease Areas
  const diseaseAreas = await Promise.all([
    prisma.diseaseArea.upsert({
      where: { code: 'RETINA' },
      update: {},
      create: {
        code: 'RETINA',
        name: 'Retina',
        therapeuticArea: 'Ophthalmology',
      },
    }),
    prisma.diseaseArea.upsert({
      where: { code: 'DRY_EYE' },
      update: {},
      create: {
        code: 'DRY_EYE',
        name: 'Dry Eye',
        therapeuticArea: 'Ophthalmology',
      },
    }),
    prisma.diseaseArea.upsert({
      where: { code: 'GLAUCOMA' },
      update: {},
      create: {
        code: 'GLAUCOMA',
        name: 'Glaucoma',
        therapeuticArea: 'Ophthalmology',
      },
    }),
    prisma.diseaseArea.upsert({
      where: { code: 'CORNEA' },
      update: {},
      create: {
        code: 'CORNEA',
        name: 'Cornea',
        therapeuticArea: 'Ophthalmology',
      },
    }),
  ]);

  console.log(`✅ Created ${diseaseAreas.length} disease areas`);

  // Create sample client
  const client = await prisma.client.upsert({
    where: { id: 'sample-client-1' },
    update: {},
    create: {
      id: 'sample-client-1',
      name: 'Sample Pharma Corp',
      type: 'FULL',
      primaryColor: '#0066CC',
    },
  });

  console.log(`✅ Created sample client: ${client.name}`);

  // Create core survey sections
  const sections = await Promise.all([
    prisma.sectionTemplate.upsert({
      where: { id: 'section-demographics' },
      update: {},
      create: {
        id: 'section-demographics',
        name: 'Demographics',
        description: 'Basic physician information',
        isCore: true,
        sortOrder: 1,
      },
    }),
    prisma.sectionTemplate.upsert({
      where: { id: 'section-national-advisors' },
      update: {},
      create: {
        id: 'section-national-advisors',
        name: 'National Advisors',
        description: 'National KOL nominations',
        isCore: true,
        sortOrder: 2,
      },
    }),
    prisma.sectionTemplate.upsert({
      where: { id: 'section-local-advisors' },
      update: {},
      create: {
        id: 'section-local-advisors',
        name: 'Local Advisors',
        description: 'Regional KOL nominations',
        isCore: true,
        sortOrder: 3,
      },
    }),
    prisma.sectionTemplate.upsert({
      where: { id: 'section-rising-stars' },
      update: {},
      create: {
        id: 'section-rising-stars',
        name: 'Rising Stars',
        description: 'Emerging KOL nominations',
        isCore: true,
        sortOrder: 4,
      },
    }),
  ]);

  console.log(`✅ Created ${sections.length} core sections`);

  // Create sample questions
  const questions = await Promise.all([
    prisma.question.upsert({
      where: { id: 'q-specialty' },
      update: {},
      create: {
        id: 'q-specialty',
        text: 'What is your primary specialty?',
        type: 'DROPDOWN',
        category: 'Demographics',
        isRequired: true,
        options: ['Retina', 'Cornea', 'Glaucoma', 'Comprehensive', 'Other'],
        tags: ['demographics', 'core'],
      },
    }),
    prisma.question.upsert({
      where: { id: 'q-years-practice' },
      update: {},
      create: {
        id: 'q-years-practice',
        text: 'How many years have you been in practice?',
        type: 'NUMBER',
        category: 'Demographics',
        isRequired: true,
        tags: ['demographics', 'core'],
      },
    }),
    prisma.question.upsert({
      where: { id: 'q-national-advisors' },
      update: {},
      create: {
        id: 'q-national-advisors',
        text: 'Who would you consider to be national thought leaders in this disease area?',
        type: 'MULTI_TEXT',
        category: 'Nominations',
        isRequired: true,
        tags: ['nominations', 'national', 'core'],
      },
    }),
    prisma.question.upsert({
      where: { id: 'q-local-advisors' },
      update: {},
      create: {
        id: 'q-local-advisors',
        text: 'Who would you consider to be regional thought leaders in your area?',
        type: 'MULTI_TEXT',
        category: 'Nominations',
        isRequired: true,
        tags: ['nominations', 'local', 'core'],
      },
    }),
    prisma.question.upsert({
      where: { id: 'q-rising-stars' },
      update: {},
      create: {
        id: 'q-rising-stars',
        text: 'Who do you see as emerging thought leaders in this space?',
        type: 'MULTI_TEXT',
        category: 'Nominations',
        isRequired: false,
        tags: ['nominations', 'rising-stars', 'core'],
      },
    }),
  ]);

  console.log(`✅ Created ${questions.length} sample questions`);

  console.log('🎉 Seeding complete!');
}

main()
  .catch((e) => {
    console.error('❌ Seed error:', e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
```

Add to `apps/api/package.json`:
```json
{
  "prisma": {
    "seed": "tsx prisma/seed.ts"
  }
}
```

---

## Migration Commands

```bash
# Create and run migration
pnpm db:migrate --name init

# Generate Prisma client
pnpm db:generate

# Seed database
pnpm db:seed

# Open Prisma Studio (visual database browser)
pnpm db:studio
```

---

## Acceptance Criteria

- [ ] Migration creates all tables without errors
- [ ] Prisma client generates successfully
- [ ] Seed script populates initial data:
  - 4 Disease Areas (Retina, Dry Eye, Glaucoma, Cornea)
  - 1 Sample Client
  - 4 Core Section Templates
  - 5 Sample Questions
- [ ] Prisma Studio shows all tables and relationships
- [ ] Foreign key relationships work correctly
- [ ] Indexes created as specified

---

## Next Module
→ `0C-authentication.md` - AWS Cognito integration
